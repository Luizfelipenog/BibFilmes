Bib Filmes é uma biblioteca na linguagem python, desenvolvida na disciplina de Programação orientada a objetos 2 na Universidade federal do Piauí!
Suas principais funções:
1-Dado um gênero de filme, rankear os principais por avaliação;
2-Dado um gênero, recomendar um filme sobre aquele gênero;
3-Realizar uma tabela sobre informações pertinentes daquele filme.
